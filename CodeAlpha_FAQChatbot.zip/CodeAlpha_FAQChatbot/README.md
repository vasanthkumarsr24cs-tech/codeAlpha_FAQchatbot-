# CodeAlpha FAQ Chatbot

Task 2: FAQ chatbot using NLP, TF-IDF and cosine similarity.

## Run
1. `pip install -r requirements.txt`
2. `python app.py`
3. Open http://127.0.0.1:5000
